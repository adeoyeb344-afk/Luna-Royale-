/**
 * Safe HTTP/JSON parsing utilities for client API requests.
 * Prevents "Unexpected token '<', <!DOCTYPE ... is not valid JSON" and
 * "Unexpected end of JSON input" when a static host or proxy returns HTML or empty body.
 */

export async function safeParseJsonResponse<T = any>(
  res: Response
): Promise<{ data: T | null; isHtml: boolean; rawText: string }> {
  try {
    const rawText = await res.text();
    const trimmed = rawText.trim();
    if (!trimmed) {
      return { data: null, isHtml: false, rawText: '' };
    }

    const contentType = res.headers.get('content-type') || '';
    const looksLikeHtml =
      contentType.toLowerCase().includes('text/html') ||
      trimmed.startsWith('<!DOCTYPE') ||
      trimmed.startsWith('<!doctype') ||
      trimmed.startsWith('<html');

    if (looksLikeHtml) {
      return { data: null, isHtml: true, rawText: trimmed };
    }

    const data = JSON.parse(trimmed) as T;
    return { data, isHtml: false, rawText: trimmed };
  } catch {
    return { data: null, isHtml: false, rawText: '' };
  }
}
