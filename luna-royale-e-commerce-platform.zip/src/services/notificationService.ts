import { safeParseJsonResponse } from './httpUtils';

export interface NotificationItem {
  name: string;
  quantity: number;
  price: number;
  categoryLabel?: string;
}

export interface ClientOrderNotificationPayload {
  orderId: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  items: NotificationItem[];
  subtotal: number;
  shippingFee: number;
  totalAmount: number;
  deliveryAddress: string;
  courier: string;
  paymentStatus: string;
  paymentReference?: string;
  deliveryPaymentMethod?: string;
}

export interface NotificationLog {
  id: string;
  timestamp: string;
  channel: 'email' | 'whatsapp';
  orderId: string;
  recipient: string;
  status: 'delivered' | 'pending_credentials' | 'failed' | 'simulated';
  provider: string;
  messagePreview: string;
  errorDetails?: string;
  isTest?: boolean;
}

export interface NotificationConfigStatus {
  adminEmail: string;
  adminWhatsApp: string;
  email: {
    hasResend: boolean;
    hasSendGrid: boolean;
    hasSmtp: boolean;
    activeProvider: string;
  };
  whatsapp: {
    hasMeta: boolean;
    hasTwilio: boolean;
    metaPhoneId: string | null;
    templateName: string;
    activeProvider: string;
  };
}

/**
 * Notifies the store administrator (Email & WhatsApp) from the server.
 * Completely non-blocking: failure will never interrupt customer checkout.
 */
export async function notifyAdminOrderCreated(
  payload: ClientOrderNotificationPayload
): Promise<void> {
  try {
    await fetch('/api/notifications/order-created', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload),
    });
  } catch (err) {
    // Non-blocking: log warning only, never throw to customer
    console.warn('Could not contact notification server (non-blocking):', err);
  }
}

/**
 * Retrieves delivery logs for administrator dashboard.
 */
export async function fetchNotificationLogs(): Promise<NotificationLog[]> {
  try {
    const res = await fetch('/api/notifications/logs');
    if (!res.ok) return [];
    const { data } = await safeParseJsonResponse(res);
    return Array.isArray(data?.logs) ? data.logs : [];
  } catch {
    return [];
  }
}

/**
 * Retrieves notification provider configuration status.
 */
export async function fetchNotificationConfig(): Promise<NotificationConfigStatus | null> {
  try {
    const res = await fetch('/api/notifications/config');
    if (!res.ok) return null;
    const { data } = await safeParseJsonResponse<NotificationConfigStatus>(res);
    return data;
  } catch {
    return null;
  }
}

/**
 * Triggers a test notification for email, whatsapp, or both.
 */
export async function triggerTestNotification(
  channel: 'email' | 'whatsapp' | 'both' = 'both'
): Promise<{
  ok: boolean;
  testOrder?: string;
  emailResult?: any;
  whatsAppResult?: any;
  error?: string;
}> {
  try {
    const res = await fetch('/api/notifications/test', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ channel }),
    });
    const { data, isHtml } = await safeParseJsonResponse(res);
    if (isHtml) {
      return {
        ok: false,
        error: 'Notification API returned HTML instead of JSON. Ensure Netlify Functions are deployed.',
      };
    }
    if (!res.ok || !data) {
      return { ok: false, error: data?.error || `Test failed (HTTP ${res.status}).` };
    }
    return data;
  } catch (err: any) {
    return { ok: false, error: err?.message || 'Network error' };
  }
}
