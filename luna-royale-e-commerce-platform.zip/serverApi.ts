import crypto from 'crypto';
import dotenv from 'dotenv';
import express from 'express';
import { GoogleGenAI, Type } from '@google/genai';
import {
  dispatchNewOrderNotifications,
  getAdminEmail,
  getAdminWhatsApp,
  getNotificationLogs,
  OrderNotificationPayload,
  sendAdminOrderEmail,
  sendAdminOrderWhatsApp,
} from './serverNotifications';

dotenv.config();

export function createApiApp(): express.Express {
  const app = express();

  // Basic CORS headers to support Netlify previews and local dev
  app.use((req, res, next) => {
    const origin = req.headers.origin;
    if (origin) {
      res.setHeader('Access-Control-Allow-Origin', origin);
    } else {
      res.setHeader('Access-Control-Allow-Origin', '*');
    }
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.setHeader(
      'Access-Control-Allow-Headers',
      'Content-Type, Authorization, X-Paystack-Signature, X-Requested-With'
    );
    res.setHeader('Access-Control-Allow-Credentials', 'true');
    if (req.method === 'OPTIONS') {
      res.status(200).end();
      return;
    }
    next();
  });

  app.use(
    express.json({
      limit: '25mb',
      verify: (req: any, _res, buf) => {
        req.rawBody = buf;
      },
    })
  );

  // ---------------------------------------------------------------------------
  // Ephemeral In-Memory Redirect Handoff Bridge (for Cross-Site Iframe Preview)
  // Allows top-level signInWithRedirect() + getRedirectResult() to securely
  // hand off the resulting Google OAuth credential back to the preview iframe.
  // ---------------------------------------------------------------------------
  const redirectHandoffStore = new Map<
    string,
    { idToken: string | null; accessToken: string | null; expiresAt: number }
  >();

  // ---------------------------------------------------------------------------
  // Server-Side Payment Architecture (Paystack Live Ready)
  // Never exposes secret credentials to the frontend.
  // Never invents transaction records, surcharges, or fees.
  // ---------------------------------------------------------------------------
  const processedWebhookReferences = new Set<string>();

  let runtimePaystackConfig: {
    secretKey: string;
    publicKey: string;
  } = {
    secretKey: process.env.PAYSTACK_SECRET_KEY?.trim() || '',
    publicKey: process.env.VITE_PAYSTACK_PUBLIC_KEY?.trim() || '',
  };

  const getPaystackSecretKey = (): string => {
    const raw = runtimePaystackConfig.secretKey || process.env.PAYSTACK_SECRET_KEY || '';
    if (!raw || raw.trim().length === 0 || raw.includes('MY_')) {
      return '';
    }
    return raw.trim();
  };

  const handlePaymentStatus = (_req: express.Request, res: express.Response) => {
    const secretKey = getPaystackSecretKey();
    const isPaystackConfigured = Boolean(secretKey.length > 0);
    const isLive = secretKey.startsWith('sk_live_');
    const isTest = secretKey.startsWith('sk_test_');

    res.json({
      gateway: 'paystack',
      configured: isPaystackConfigured,
      currency: 'NGN',
      mode: isLive ? 'live' : isTest ? 'test' : isPaystackConfigured ? 'custom' : 'unconfigured',
      maskedSecretKey: isPaystackConfigured
        ? `${secretKey.substring(0, 7)}...${secretKey.slice(-4)}`
        : null,
      publicKey: runtimePaystackConfig.publicKey || process.env.VITE_PAYSTACK_PUBLIC_KEY?.trim() || null,
      message: isPaystackConfigured
        ? `Paystack ${isLive ? 'LIVE' : 'TEST'} mode active on server.`
        : 'Paystack Live payment gateway is not yet configured on the server. Please add PAYSTACK_SECRET_KEY in Netlify Site Configuration -> Environment Variables or configure in Admin Dashboard.',
    });
  };

  const handlePaymentConfig = (req: express.Request, res: express.Response) => {
    const { secretKey, publicKey } = req.body || {};
    if (typeof secretKey === 'string' && secretKey.trim().length > 0) {
      const cleanKey = secretKey.trim();
      if (!cleanKey.startsWith('sk_live_') && !cleanKey.startsWith('sk_test_')) {
        res.status(400).json({
          error:
            'Invalid Paystack secret key format. It must start with "sk_live_" for Live transactions or "sk_test_" for Test mode.',
        });
        return;
      }
      runtimePaystackConfig.secretKey = cleanKey;
    }

    if (typeof publicKey === 'string') {
      runtimePaystackConfig.publicKey = publicKey.trim();
    }

    const currentKey = getPaystackSecretKey();
    const isLive = currentKey.startsWith('sk_live_');
    const isTest = currentKey.startsWith('sk_test_');

    res.json({
      ok: true,
      configured: Boolean(currentKey.length > 0),
      gateway: 'paystack',
      mode: isLive ? 'live' : isTest ? 'test' : 'unconfigured',
      maskedSecretKey: currentKey ? `${currentKey.substring(0, 7)}...${currentKey.slice(-4)}` : null,
      message: currentKey
        ? `Paystack ${isLive ? 'LIVE' : 'TEST'} mode configured successfully on server.`
        : 'Paystack is unconfigured.',
    });
  };

  const handlePaymentInitialize = async (req: express.Request, res: express.Response) => {
    const secretKey = getPaystackSecretKey();
    if (!secretKey) {
      res.status(503).json({
        error:
          'Paystack Live secret key is not yet configured on the server. Please configure PAYSTACK_SECRET_KEY in Netlify environment variables.',
        configured: false,
      });
      return;
    }

    const { email, amountNaira, reference, metadata, callbackUrl, items, orderId } =
      req.body || {};

    if (!email || typeof email !== 'string' || !email.includes('@')) {
      res.status(400).json({ error: 'A valid customer email is required.' });
      return;
    }

    const cleanOrderId = typeof orderId === 'string' ? orderId.trim() : metadata?.orderId || null;
    let validatedAmountNaira = typeof amountNaira === 'number' ? amountNaira : Number(amountNaira);

    if (!Number.isFinite(validatedAmountNaira) || validatedAmountNaira <= 0) {
      res.status(400).json({ error: 'A valid positive NGN amount is required.' });
      return;
    }

    // -------------------------------------------------------------------------
    // Server-Side Trusted Order & Shipping Fee Validation (Zero Trust in Browser)
    // -------------------------------------------------------------------------
    if (cleanOrderId) {
      const authHeader = req.headers.authorization;
      const idToken =
        typeof authHeader === 'string' && authHeader.startsWith('Bearer ')
          ? authHeader.slice(7).trim()
          : null;

      if (idToken) {
        try {
          const firestoreUrl = `https://firestore.googleapis.com/v1/projects/luna-royale/databases/(default)/documents/orders/${encodeURIComponent(
            cleanOrderId
          )}`;

          const orderResponse = await fetch(firestoreUrl, {
            method: 'GET',
            headers: {
              Authorization: `Bearer ${idToken}`,
              'Content-Type': 'application/json',
            },
          });

          if (!orderResponse.ok) {
            if (orderResponse.status === 404) {
              res.status(404).json({ error: 'Order not found in the atelier registry.' });
              return;
            }
            if (orderResponse.status === 403 || orderResponse.status === 401) {
              res.status(403).json({ error: 'Unauthorized to initiate payment for this order.' });
              return;
            }
          } else {
            const rawOrderText = await orderResponse.text();
            const rawOrderDoc = (rawOrderText && rawOrderText.trim() && !rawOrderText.trim().startsWith('<')
              ? JSON.parse(rawOrderText)
              : {}) as { fields?: Record<string, any> };
            const fields = rawOrderDoc.fields || {};

            const parseVal = (val: any): any => {
              if (!val || typeof val !== 'object') return val;
              if ('stringValue' in val) return val.stringValue;
              if ('integerValue' in val) return Number(val.integerValue);
              if ('doubleValue' in val) return Number(val.doubleValue);
              if ('booleanValue' in val) return val.booleanValue;
              if ('nullValue' in val) return null;
              if ('arrayValue' in val) return (val.arrayValue.values || []).map(parseVal);
              if ('mapValue' in val) {
                const mapObj: Record<string, any> = {};
                for (const [k, v] of Object.entries(val.mapValue.fields || {})) {
                  mapObj[k] = parseVal(v);
                }
                return mapObj;
              }
              return val;
            };

            const orderData: Record<string, any> = {};
            for (const [k, v] of Object.entries(fields)) {
              orderData[k] = parseVal(v);
            }

            // 1. Enforce that shipping fee MUST be confirmed before payment
            if (orderData.shippingStatus !== 'confirmed') {
              res.status(400).json({
                error:
                  'Shipping fee has not yet been confirmed by the atelier. Payment cannot proceed until shipping is confirmed by an administrator.',
                shippingStatus: orderData.shippingStatus || 'pending_confirmation',
              });
              return;
            }

            // 2. Prevent duplicate payment if already confirmed/paid
            if (
              orderData.status === 'confirmed' ||
              orderData.status === 'processing' ||
              orderData.status === 'shipped' ||
              orderData.status === 'delivered'
            ) {
              res.status(400).json({
                error: 'This order has already been paid and confirmed.',
                status: orderData.status,
              });
              return;
            }

            // 3. Compute trusted payable amount: Items Subtotal + Confirmed Shipping Fee
            const trustedItemsSubtotal =
              typeof orderData.subtotal === 'number'
                ? orderData.subtotal
                : Number(orderData.subtotal || 0);

            const trustedShippingFee =
              typeof orderData.shippingFee === 'number'
                ? orderData.shippingFee
                : Number(orderData.shippingFee || 0);

            if (!Number.isFinite(trustedShippingFee) || trustedShippingFee < 0) {
              res.status(400).json({
                error: 'Confirmed shipping fee is invalid on the server.',
              });
              return;
            }

            const isPayOnArrival = orderData.deliveryPaymentMethod === 'courier_on_arrival';
            const expectedTotal = isPayOnArrival
              ? trustedItemsSubtotal
              : trustedItemsSubtotal + trustedShippingFee;

            if (Math.abs(validatedAmountNaira - expectedTotal) > 0.05) {
              res.status(400).json({
                error: `Order total mismatch. The expected amount is ₦${expectedTotal.toLocaleString()} (Items: ₦${trustedItemsSubtotal.toLocaleString()}${isPayOnArrival ? ' - Delivery paid on arrival' : ` + Shipping: ₦${trustedShippingFee.toLocaleString()}`}).`,
              });
              return;
            }

            // Always enforce trusted server total exactly
            validatedAmountNaira = expectedTotal;
          }
        } catch (fetchErr) {
          console.warn('Firestore order validation fallback:', fetchErr);
        }
      }
    } else if (Array.isArray(items) && items.length > 0) {
      // Direct cart items check if orderId was not yet created
      let calculatedSum = 0;
      for (const item of items) {
        const itemPrice = typeof item.price === 'number' ? item.price : Number(item.price);
        const itemQuantity = typeof item.quantity === 'number' ? item.quantity : Number(item.quantity);
        if (Number.isFinite(itemPrice) && Number.isFinite(itemQuantity) && itemPrice >= 0 && itemQuantity > 0) {
          calculatedSum += itemPrice * itemQuantity;
        }
      }
      const rawDeliveryFee =
        typeof req.body.deliveryFee === 'number' ? req.body.deliveryFee : Number(req.body.deliveryFee || 0);
      const deliveryFee = Number.isFinite(rawDeliveryFee) && rawDeliveryFee >= 0 ? rawDeliveryFee : 0;
      const expectedTotal = calculatedSum + (req.body.deliveryPaymentMethod === 'courier_on_arrival' ? 0 : deliveryFee);

      if (calculatedSum > 0 && Math.abs(expectedTotal - validatedAmountNaira) > 0.05) {
        res.status(400).json({
          error: 'Order total mismatch. The amount provided does not match item total calculations.',
        });
        return;
      }
    }

    // Exact amount in kobo (LUNA ROYALE absorbs gateway fee, no surcharge added)
    const amountKobo = Math.round(validatedAmountNaira * 100);
    const cleanReference =
      typeof reference === 'string' && /^[a-zA-Z0-9_-]{8,128}$/.test(reference.trim())
        ? reference.trim()
        : `lr_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;

    const effectiveCallbackUrl =
      typeof callbackUrl === 'string' && callbackUrl.trim().length > 0
        ? callbackUrl.trim()
        : typeof req.headers.origin === 'string'
          ? `${req.headers.origin}/cart`
          : undefined;

    const paystackPayload: Record<string, unknown> = {
      email: email.trim().toLowerCase(),
      amount: amountKobo,
      currency: 'NGN',
      reference: cleanReference,
      metadata: {
        orderId: cleanOrderId || undefined,
        custom_fields: [
          {
            display_name: 'Store',
            variable_name: 'store',
            value: 'LUNA ROYALE',
          },
          ...(cleanOrderId
            ? [
                {
                  display_name: 'Order ID',
                  variable_name: 'order_id',
                  value: cleanOrderId,
                },
              ]
            : []),
        ],
        ...(metadata && typeof metadata === 'object' ? metadata : {}),
      },
    };

    if (effectiveCallbackUrl) {
      paystackPayload.callback_url = effectiveCallbackUrl;
    }

    try {
      const response = await fetch('https://api.paystack.co/transaction/initialize', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${secretKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(paystackPayload),
      });

      const rawText = await response.text();
      let data: any = null;
      try {
        data = rawText && rawText.trim() && !rawText.trim().startsWith('<') ? JSON.parse(rawText) : null;
      } catch {
        data = null;
      }
      if (!response.ok || !data || !data.status) {
        res.status(400).json({
          error: data?.message || 'Unable to initialize payment with Paystack.',
        });
        return;
      }

      res.json({
        status: true,
        authorization_url: data.data.authorization_url,
        access_code: data.data.access_code,
        reference: data.data.reference,
      });
    } catch {
      res.status(500).json({ error: 'Payment gateway communication failed.' });
    }
  };

  const handlePaymentVerify = async (req: express.Request, res: express.Response) => {
    const secretKey = getPaystackSecretKey();
    if (!secretKey) {
      res.status(503).json({
        error:
          'Paystack Live secret key is not yet configured on the server. Please configure PAYSTACK_SECRET_KEY in Netlify environment variables.',
        configured: false,
        verified: false,
      });
      return;
    }

    const { reference } = req.params;
    if (!reference || !/^[a-zA-Z0-9_-]{6,128}$/.test(reference)) {
      res.status(400).json({ error: 'Invalid payment reference.', verified: false });
      return;
    }

    try {
      const response = await fetch(
        `https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`,
        {
          method: 'GET',
          headers: {
            Authorization: `Bearer ${secretKey}`,
          },
        }
      );

      const rawText = await response.text();
      let data: any = null;
      try {
        data = rawText && rawText.trim() && !rawText.trim().startsWith('<') ? JSON.parse(rawText) : null;
      } catch {
        data = null;
      }
      if (!response.ok || !data || !data.status) {
        res.status(400).json({
          error: data?.message || 'Unable to verify transaction.',
          verified: false,
        });
        return;
      }

      const tx = data.data;
      const isSuccess = tx.status === 'success';

      res.json({
        status: true,
        verified: isSuccess,
        transaction: {
          reference: tx.reference,
          status: tx.status,
          amount: tx.amount / 100,
          currency: tx.currency,
          paidAt: tx.paid_at,
          channel: tx.channel,
          orderId: tx.metadata?.orderId || null,
          gatewayResponse: tx.gateway_response,
        },
      });
    } catch {
      res.status(500).json({ error: 'Transaction verification failed.', verified: false });
    }
  };

  // Paystack Webhook Handler (HMAC SHA-512 Verification)
  const handlePaystackWebhook = (req: express.Request, res: express.Response) => {
    const secretKey = getPaystackSecretKey();
    if (!secretKey) {
      res.status(503).json({ error: 'Paystack secret key is not configured.' });
      return;
    }

    const signature = req.headers['x-paystack-signature'];
    if (!signature || typeof signature !== 'string') {
      res.status(401).json({ error: 'Missing x-paystack-signature header.' });
      return;
    }

    const payloadBuffer = (req as any).rawBody || Buffer.from(JSON.stringify(req.body));
    const computedSignature = crypto
      .createHmac('sha512', secretKey)
      .update(payloadBuffer)
      .digest('hex');

    if (signature !== computedSignature) {
      res.status(401).json({ error: 'Invalid webhook signature.' });
      return;
    }

    const event = req.body;
    if (event && event.event === 'charge.success') {
      const data = event.data;
      const reference = data?.reference;

      if (reference) {
        // Idempotent processing: prevent repeated handling of identical references
        if (processedWebhookReferences.has(reference)) {
          res.status(200).json({ received: true, alreadyProcessed: true });
          return;
        }

        // Limit size of processed set to prevent memory growth
        if (processedWebhookReferences.size > 5000) {
          processedWebhookReferences.clear();
        }
        processedWebhookReferences.add(reference);
      }
    }

    // Paystack requires immediate 200 response to acknowledge receipt
    res.status(200).json({ received: true });
  };

  // ---------------------------------------------------------------------------
  // Server-Side Administrator Notifications (Email & WhatsApp Business)
  // ---------------------------------------------------------------------------
  const handleOrderNotification = async (req: express.Request, res: express.Response) => {
    try {
      const payload = req.body as OrderNotificationPayload;
      if (!payload || !payload.orderId) {
        res.status(400).json({ error: 'Missing order notification payload.' });
        return;
      }

      const safePayload: OrderNotificationPayload = {
        orderId: String(payload.orderId).trim(),
        customerName: String(payload.customerName || 'Customer').trim(),
        customerEmail: String(payload.customerEmail || '').trim(),
        customerPhone: String(payload.customerPhone || '').trim(),
        items: Array.isArray(payload.items) ? payload.items : [],
        subtotal: Number(payload.subtotal) || 0,
        shippingFee: Number(payload.shippingFee) || 0,
        totalAmount: Number(payload.totalAmount) || 0,
        deliveryAddress: String(payload.deliveryAddress || 'Address on file').trim(),
        courier: String(payload.courier || 'Standard Courier').trim(),
        paymentStatus: String(payload.paymentStatus || 'Pending Payment').trim(),
        paymentReference: payload.paymentReference ? String(payload.paymentReference).trim() : undefined,
        deliveryPaymentMethod: payload.deliveryPaymentMethod,
        isTest: Boolean(payload.isTest),
      };

      const result = await dispatchNewOrderNotifications(safePayload);
      res.json({ ok: true, ...result });
    } catch (err: any) {
      console.warn('Notification handler exception (non-fatal):', err);
      res.status(200).json({ ok: false, error: err?.message || 'Notification error' });
    }
  };

  const handleNotificationLogs = (_req: express.Request, res: express.Response) => {
    res.json({ logs: getNotificationLogs() });
  };

  const handleNotificationConfig = (_req: express.Request, res: express.Response) => {
    const adminEmail = getAdminEmail();
    const adminWhatsApp = getAdminWhatsApp();
    const resendKey = process.env.RESEND_API_KEY?.trim() || '';
    const sendgridKey = process.env.SENDGRID_API_KEY?.trim() || '';
    const smtpHost = process.env.SMTP_HOST?.trim() || '';
    const metaToken = process.env.WHATSAPP_API_TOKEN?.trim() || '';
    const metaPhoneId = process.env.WHATSAPP_PHONE_NUMBER_ID?.trim() || '';
    const twilioSid = process.env.TWILIO_ACCOUNT_SID?.trim() || '';

    res.json({
      adminEmail,
      adminWhatsApp,
      email: {
        hasResend: Boolean(resendKey && !resendKey.includes('MY_')),
        hasSendGrid: Boolean(sendgridKey && !sendgridKey.includes('MY_')),
        hasSmtp: Boolean(smtpHost && process.env.SMTP_USER),
        activeProvider:
          resendKey && !resendKey.includes('MY_')
            ? 'Resend API'
            : sendgridKey && !sendgridKey.includes('MY_')
              ? 'SendGrid API'
              : smtpHost
                ? `SMTP (${smtpHost})`
                : 'Pending Provider Credentials',
      },
      whatsapp: {
        hasMeta: Boolean(metaToken && metaPhoneId && !metaToken.includes('MY_')),
        hasTwilio: Boolean(twilioSid),
        metaPhoneId: metaPhoneId ? `${metaPhoneId.substring(0, 4)}...${metaPhoneId.slice(-4)}` : null,
        templateName: process.env.WHATSAPP_TEMPLATE_NAME?.trim() || 'new_order_alert',
        activeProvider:
          metaToken && metaPhoneId && !metaToken.includes('MY_')
            ? 'Meta WhatsApp Cloud API'
            : twilioSid
              ? 'Twilio WhatsApp'
              : 'Pending Provider Credentials',
      },
    });
  };

  const handleNotificationTest = async (req: express.Request, res: express.Response) => {
    try {
      const channel = req.body?.channel || 'both';
      const testPayload: OrderNotificationPayload = {
        orderId: `LR-TEST-${Math.floor(1000 + Math.random() * 9000)}`,
        customerName: 'Adeoye (Store Administrator)',
        customerEmail: getAdminEmail(),
        customerPhone: getAdminWhatsApp(),
        items: [
          { name: 'The Royale Scent Extrait', quantity: 1, price: 85000, categoryLabel: 'Perfume' },
          { name: 'Luna Celestial Earrings', quantity: 1, price: 65000, categoryLabel: 'Jewelry' },
        ],
        subtotal: 150000,
        shippingFee: 5000,
        totalAmount: 155000,
        deliveryAddress: 'LUNA ROYALE Atelier, Victoria Island, Lagos',
        courier: 'Standard Lagos Delivery',
        paymentStatus: 'Paid with Paystack (Test Simulation)',
        paymentReference: `lr_test_ref_${Date.now()}`,
        isTest: true,
      };

      let emailResult = null;
      let whatsAppResult = null;

      if (channel === 'email' || channel === 'both') {
        emailResult = await sendAdminOrderEmail(testPayload);
      }
      if (channel === 'whatsapp' || channel === 'both') {
        whatsAppResult = await sendAdminOrderWhatsApp(testPayload);
      }

      res.json({
        ok: true,
        testOrder: testPayload.orderId,
        emailResult,
        whatsAppResult,
      });
    } catch (err: any) {
      res.status(500).json({ ok: false, error: err?.message || 'Failed to trigger test' });
    }
  };

  // ---------------------------------------------------------------------------
  // Cloudinary Architecture (Signed & Unsigned)
  // ---------------------------------------------------------------------------
  let runtimeCloudinaryConfig: {
    cloudName: string;
    uploadPreset: string;
  } = {
    cloudName:
      process.env.CLOUDINARY_CLOUD_NAME?.trim() ||
      process.env.VITE_CLOUDINARY_CLOUD_NAME?.trim() ||
      '',
    uploadPreset:
      process.env.CLOUDINARY_UPLOAD_PRESET?.trim() ||
      process.env.VITE_CLOUDINARY_UPLOAD_PRESET?.trim() ||
      '',
  };

  function getResolvedCloudinaryConfig() {
    const cloudName =
      process.env.CLOUDINARY_CLOUD_NAME?.trim() ||
      process.env.VITE_CLOUDINARY_CLOUD_NAME?.trim() ||
      runtimeCloudinaryConfig.cloudName ||
      '';
    const uploadPreset =
      process.env.CLOUDINARY_UPLOAD_PRESET?.trim() ||
      process.env.VITE_CLOUDINARY_UPLOAD_PRESET?.trim() ||
      runtimeCloudinaryConfig.uploadPreset ||
      '';
    const apiKey = process.env.CLOUDINARY_API_KEY?.trim() || '';
    const apiSecret = process.env.CLOUDINARY_API_SECRET?.trim() || '';

    const hasSignedCredentials = Boolean(cloudName && apiKey && apiSecret);
    const hasUnsignedPreset = Boolean(cloudName && uploadPreset);

    return {
      cloudName,
      uploadPreset,
      apiKey,
      apiSecret,
      hasSignedCredentials,
      hasUnsignedPreset,
      configured: hasSignedCredentials || hasUnsignedPreset,
      mode: hasSignedCredentials
        ? ('signed' as const)
        : hasUnsignedPreset
          ? ('unsigned' as const)
          : ('unconfigured' as const),
    };
  }

  const handleMediaStatus = (_req: express.Request, res: express.Response) => {
    const cfg = getResolvedCloudinaryConfig();
    res.json({
      provider: 'cloudinary',
      configured: cfg.configured,
      mode: cfg.mode,
      cloudName: cfg.cloudName || null,
      uploadPreset: cfg.uploadPreset || null,
    });
  };

  const handleMediaConfig = (req: express.Request, res: express.Response) => {
    const cloudName =
      typeof req.body?.cloudName === 'string' ? req.body.cloudName.trim() : '';
    const uploadPreset =
      typeof req.body?.uploadPreset === 'string' ? req.body.uploadPreset.trim() : '';

    if (!cloudName || !uploadPreset) {
      res.status(400).json({
        error: 'Both Cloudinary Cloud Name and Unsigned Upload Preset are required.',
      });
      return;
    }

    if (
      !/^[a-zA-Z0-9_-]{1,120}$/.test(cloudName) ||
      !/^[a-zA-Z0-9_-]{1,120}$/.test(uploadPreset)
    ) {
      res.status(400).json({
        error:
          'Invalid Cloud Name or Upload Preset format. Use alphanumeric characters, hyphens, or underscores.',
      });
      return;
    }

    runtimeCloudinaryConfig = { cloudName, uploadPreset };
    const cfg = getResolvedCloudinaryConfig();

    res.json({
      provider: 'cloudinary',
      configured: cfg.configured,
      mode: cfg.mode,
      cloudName: cfg.cloudName,
      uploadPreset: cfg.uploadPreset,
    });
  };

  const handleMediaSignature = (req: express.Request, res: express.Response) => {
    const cfg = getResolvedCloudinaryConfig();

    if (!cfg.hasSignedCredentials) {
      res.status(503).json({
        error:
          'Cloudinary signed upload credentials (CLOUDINARY_CLOUD_NAME, CLOUDINARY_API_KEY, CLOUDINARY_API_SECRET) are not configured on the server.',
        configured: cfg.configured,
        mode: cfg.mode,
      });
      return;
    }

    const timestamp = Math.round(Date.now() / 1000);
    const folder =
      typeof req.body?.folder === 'string' && req.body.folder.trim()
        ? req.body.folder.trim()
        : 'luna-royale/products';
    const paramsToSign = `folder=${folder}&timestamp=${timestamp}${cfg.apiSecret}`;
    const signature = crypto.createHash('sha1').update(paramsToSign).digest('hex');

    res.json({
      cloudName: cfg.cloudName,
      apiKey: cfg.apiKey,
      timestamp,
      folder,
      signature,
    });
  };

  const handleMediaUpload = async (req: express.Request, res: express.Response) => {
    const cfg = getResolvedCloudinaryConfig();
    const {
      fileDataUrl,
      folder: requestedFolder,
      cloudName: reqCloudName,
      uploadPreset: reqUploadPreset,
    } = req.body || {};

    if (typeof fileDataUrl !== 'string' || !fileDataUrl.startsWith('data:image/')) {
      res.status(400).json({ error: 'A valid image file is required for upload.' });
      return;
    }

    const effectiveCloudName =
      (typeof reqCloudName === 'string' && reqCloudName.trim()) || cfg.cloudName;
    const effectiveUploadPreset =
      (typeof reqUploadPreset === 'string' && reqUploadPreset.trim()) || cfg.uploadPreset;
    const folder =
      typeof requestedFolder === 'string' && requestedFolder.trim()
        ? requestedFolder.trim()
        : 'luna-royale/products';

    if (!effectiveCloudName) {
      res.status(503).json({
        error:
          'Cloudinary Cloud Name is missing. Set CLOUDINARY_CLOUD_NAME (and CLOUDINARY_UPLOAD_PRESET or CLOUDINARY_API_KEY + CLOUDINARY_API_SECRET).',
      });
      return;
    }

    try {
      const formData = new FormData();
      formData.append('file', fileDataUrl);
      formData.append('folder', folder);

      if (cfg.hasSignedCredentials && effectiveCloudName === cfg.cloudName) {
        const timestamp = Math.round(Date.now() / 1000);
        const paramsToSign = `folder=${folder}&timestamp=${timestamp}${cfg.apiSecret}`;
        const signature = crypto.createHash('sha1').update(paramsToSign).digest('hex');

        formData.append('api_key', cfg.apiKey);
        formData.append('timestamp', String(timestamp));
        formData.append('signature', signature);
      } else if (effectiveUploadPreset) {
        formData.append('upload_preset', effectiveUploadPreset);
      } else {
        res.status(503).json({
          error: 'Cloudinary upload preset or server API credentials are not configured.',
        });
        return;
      }

      const uploadResponse = await fetch(
        `https://api.cloudinary.com/v1_1/${encodeURIComponent(effectiveCloudName)}/image/upload`,
        {
          method: 'POST',
          body: formData,
        }
      );

      const uploadJson = (await uploadResponse.json().catch(() => ({}))) as {
        secure_url?: string;
        public_id?: string;
        error?: { message?: string };
      };

      if (!uploadResponse.ok || !uploadJson.secure_url) {
        res.status(uploadResponse.status || 400).json({
          error:
            uploadJson?.error?.message ||
            'Cloudinary rejected the image upload. Verify your Cloud Name and Upload Preset.',
        });
        return;
      }

      res.json({
        secure_url: uploadJson.secure_url,
        public_id: uploadJson.public_id || null,
      });
    } catch {
      res.status(500).json({
        error: 'Failed to communicate with Cloudinary upload service.',
      });
    }
  };

  // ---------------------------------------------------------------------------
  // LUNA ROYALE AI CONCIERGE — Server-Side Recommendation Architecture
  // ---------------------------------------------------------------------------
  const handleAiConcierge = async (req: express.Request, res: express.Response) => {
    const { mode, answers, candidateProducts } = req.body || {};

    if (!Array.isArray(candidateProducts) || candidateProducts.length === 0) {
      res.json({
        headline: 'Atelier Notice',
        conciergeNote: 'No products are available for recommendations yet.',
        recommendations: [],
        isNoMatch: true,
        noMatchExplanation: 'No products are currently available in the catalog.',
        isAiPowered: false,
      });
      return;
    }

    interface SafeProduct {
      id: string;
      name: string;
      category: string;
      description: string;
      price: number;
      availability: string;
      published: boolean;
    }

    const availableProducts: SafeProduct[] = candidateProducts.filter(
      (p: any) =>
        p &&
        typeof p.id === 'string' &&
        typeof p.name === 'string' &&
        typeof p.price === 'number' &&
        p.published === true &&
        p.availability !== 'out_of_stock'
    );

    if (availableProducts.length === 0) {
      res.json({
        headline: 'Atelier Notice',
        conciergeNote: 'No products are available for recommendations yet.',
        recommendations: [],
        isNoMatch: true,
        noMatchExplanation: 'No products are currently available in the catalog.',
        isAiPowered: false,
      });
      return;
    }

    const rawBudget = answers?.budgetMax;
    const maxBudget =
      typeof rawBudget === 'number' && Number.isFinite(rawBudget) && rawBudget > 0
        ? rawBudget
        : null;

    const budgetEligibleProducts =
      maxBudget !== null
        ? availableProducts.filter((p) => p.price <= maxBudget)
        : availableProducts;

    if (budgetEligibleProducts.length === 0) {
      res.json({
        headline: 'Budget Consultation',
        conciergeNote: 'I couldn’t find an available product within that budget right now.',
        recommendations: [],
        isNoMatch: true,
        noMatchExplanation: 'No available items fit within the selected budget threshold.',
        isAiPowered: false,
      });
      return;
    }

    const validIdMap = new Map(budgetEligibleProducts.map((p) => [p.id, p]));

    const geminiKey = process.env.GEMINI_API_KEY?.trim() || '';
    const hasGeminiKey = Boolean(geminiKey && !geminiKey.includes('MY_'));

    if (hasGeminiKey) {
      try {
        const ai = new GoogleGenAI({
          apiKey: geminiKey,
          httpOptions: {
            headers: {
              'User-Agent': 'aistudio-build',
            },
          },
        });

        const catalogListing = budgetEligibleProducts
          .map(
            (p) =>
              `- ID: "${p.id}" | Name: "${p.name}" | Category: ${p.category} | Price: ₦${p.price} | Desc: ${p.description}`
          )
          .join('\n');

        const systemInstruction = `You are the sophisticated luxury shopping concierge for LUNA ROYALE ("Elegance, Curated.").
Tone: Elegant, warm, helpful, concise, confident, refined, personal, never pushy.
CRITICAL MANDATE: You MUST ONLY recommend product IDs that exist in the exact catalog listing provided below.
Do NOT invent or hallucinate any product, set, discount, or price.
Every recommended item MUST correspond to a valid productId from the list.
Provide a concise, thoughtful explanation for each recommendation (e.g. "Recommended because you selected a minimalist style for everyday wear.").
If no product matches the customer's request, set isNoMatch to true and provide an elegant explanation.`;

        const userPrompt = `Mode: ${mode || 'style'}
Customer Answers: ${JSON.stringify(answers || {})}

Available Catalog:
${catalogListing}

Select the most suitable products from the catalog above and provide personalized luxury concierge recommendations.`;

        const response = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: userPrompt,
          config: {
            systemInstruction,
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                headline: { type: Type.STRING },
                conciergeNote: { type: Type.STRING },
                isNoMatch: { type: Type.BOOLEAN },
                noMatchExplanation: { type: Type.STRING },
                recommendations: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      productId: { type: Type.STRING },
                      reason: { type: Type.STRING },
                    },
                    required: ['productId', 'reason'],
                  },
                },
              },
              required: ['headline', 'conciergeNote', 'isNoMatch', 'recommendations'],
            },
          },
        });

        const parsed = JSON.parse(response.text || '{}');
        const rawRecs: Array<{ productId: string; reason: string }> = Array.isArray(
          parsed.recommendations
        )
          ? parsed.recommendations
          : [];

        const verifiedRecs = rawRecs.filter(
          (r) => typeof r.productId === 'string' && validIdMap.has(r.productId)
        );

        if (verifiedRecs.length > 0) {
          res.json({
            headline: parsed.headline || 'Curated by LUNA ROYALE AI Concierge',
            conciergeNote:
              parsed.conciergeNote ||
              'Based on your preferences, these pieces from our atelier suit your vision beautifully.',
            recommendations: verifiedRecs,
            isNoMatch: false,
            isAiPowered: true,
          });
          return;
        }
      } catch (geminiError) {
        console.warn('Gemini recommendation call fallback:', geminiError);
      }
    }

    // Deterministic Luxury Matching Fallback
    let filtered = [...budgetEligibleProducts];
    const category = answers?.category;
    if (category && category !== 'Any' && category !== 'Open to suggestions') {
      const catMatches = filtered.filter(
        (p) => p.category.toLowerCase() === category.toLowerCase()
      );
      if (catMatches.length > 0) {
        filtered = catMatches;
      }
    }

    let headline = 'Curated for You';
    let conciergeNote =
      'Based on your preferences, these pieces from our atelier suit your vision beautifully.';
    let recommendations: Array<{ productId: string; reason: string }> = [];

    if (mode === 'style') {
      const styleChoice = answers?.style || 'elegant';
      const occasionChoice = answers?.occasion || 'special occasions';
      headline = 'Curated for Your Style';
      conciergeNote = `Based on your preference for ${styleChoice.toLowerCase()} silhouettes and ${occasionChoice.toLowerCase()}, these LUNA ROYALE pieces reflect your personal aesthetic.`;
      recommendations = filtered.slice(0, 4).map((p) => ({
        productId: p.id,
        reason: `Recommended because you selected ${styleChoice.toLowerCase()} style for ${occasionChoice.toLowerCase()}.`,
      }));
    } else if (mode === 'gift') {
      const recipient = answers?.recipient || 'someone special';
      const occasion = answers?.occasion || 'a celebration';
      headline = `Gift Selection for ${recipient}`;
      conciergeNote = `Curated with care for your ${recipient.toLowerCase()} celebrating ${occasion.toLowerCase()}. Each piece embodies timeless presentation and refinement.`;
      recommendations = filtered.slice(0, 4).map((p) => ({
        productId: p.id,
        reason: `Recommended as a thoughtful gift for your ${recipient.toLowerCase()} on ${occasion.toLowerCase()}.`,
      }));
    } else {
      headline = 'Selected for You';
      conciergeNote =
        'A refined selection from our current catalog, curated around elegance, timeless craftsmanship, and balanced design.';
      recommendations = filtered.slice(0, 4).map((p) => ({
        productId: p.id,
        reason: 'Recommended to complement your current LUNA ROYALE preferences and taste.',
      }));
    }

    res.json({
      headline,
      conciergeNote,
      recommendations,
      isNoMatch: recommendations.length === 0,
      isAiPowered: false,
    });
  };

  // ---------------------------------------------------------------------------
  // Ephemeral Handoff Endpoints
  // ---------------------------------------------------------------------------
  const handleRedirectHandoffPost = (req: express.Request, res: express.Response) => {
    const { handoffId, idToken, accessToken } = req.body || {};
    if (
      typeof handoffId !== 'string' ||
      !/^[a-zA-Z0-9_-]{12,128}$/.test(handoffId) ||
      (!idToken && !accessToken)
    ) {
      res.status(400).json({ error: 'Invalid handoff payload.' });
      return;
    }

    const now = Date.now();
    for (const [key, entry] of redirectHandoffStore.entries()) {
      if (entry.expiresAt <= now) {
        redirectHandoffStore.delete(key);
      }
    }

    redirectHandoffStore.set(handoffId, {
      idToken: typeof idToken === 'string' ? idToken : null,
      accessToken: typeof accessToken === 'string' ? accessToken : null,
      expiresAt: now + 2 * 60 * 1000,
    });

    res.json({ ok: true });
  };

  const handleRedirectHandoffGet = (req: express.Request, res: express.Response) => {
    const { handoffId } = req.params;
    if (!handoffId || !/^[a-zA-Z0-9_-]{12,128}$/.test(handoffId)) {
      res.status(400).json({ ready: false });
      return;
    }

    const entry = redirectHandoffStore.get(handoffId);
    if (!entry || entry.expiresAt <= Date.now()) {
      redirectHandoffStore.delete(handoffId);
      res.json({ ready: false });
      return;
    }

    res.json({
      ready: true,
      idToken: entry.idToken,
      accessToken: entry.accessToken,
    });
  };

  const handleHealth = (_req: express.Request, res: express.Response) => {
    res.status(200).send('OK');
  };

  // ---------------------------------------------------------------------------
  // Register Routes on a Single Router and Mount Across All Common Netlify/Express Prefixes
  // ---------------------------------------------------------------------------
  const apiRouter = express.Router();

  // Probes & Redirect Handoff
  apiRouter.get('/health', handleHealth);
  apiRouter.get('/_health', handleHealth);
  apiRouter.post('/auth/redirect-handoff', handleRedirectHandoffPost);
  apiRouter.get('/auth/redirect-handoff/:handoffId', handleRedirectHandoffGet);

  // Payments / Paystack Endpoints
  apiRouter.get('/payments/status', handlePaymentStatus);
  apiRouter.get('/paystack/status', handlePaymentStatus);
  apiRouter.post('/payments/config', handlePaymentConfig);
  apiRouter.post('/paystack/config', handlePaymentConfig);
  apiRouter.post('/payments/initialize', handlePaymentInitialize);
  apiRouter.post('/paystack/initialize', handlePaymentInitialize);
  apiRouter.get('/payments/verify/:reference', handlePaymentVerify);
  apiRouter.get('/paystack/verify/:reference', handlePaymentVerify);
  apiRouter.post('/paystack/webhook', handlePaystackWebhook);
  apiRouter.post('/payments/webhook', handlePaystackWebhook);

  // Administrator Notifications
  apiRouter.post('/notifications/order-created', handleOrderNotification);
  apiRouter.get('/notifications/logs', handleNotificationLogs);
  apiRouter.get('/notifications/config', handleNotificationConfig);
  apiRouter.post('/notifications/test', handleNotificationTest);

  // Media / Cloudinary
  apiRouter.get('/media/status', handleMediaStatus);
  apiRouter.post('/media/config', handleMediaConfig);
  apiRouter.post('/media/signature', handleMediaSignature);
  apiRouter.post('/media/upload', handleMediaUpload);

  // AI Concierge
  apiRouter.post('/ai/concierge', handleAiConcierge);

  // Universal Path Mounts:
  // 1. /.netlify/functions/api (direct Netlify Function path)
  // 2. /api (standard rewritten path)
  // 3. / (root fallback)
  app.use('/.netlify/functions/api', apiRouter);
  app.use('/api', apiRouter);
  app.use('/', apiRouter);

  // Ensure unmatched /api/* or Netlify Function routes always return JSON (never HTML <!DOCTYPE>)
  app.use('/api/*', (_req, res) => {
    res.status(404).json({ error: 'API endpoint not found.' });
  });
  app.use('/.netlify/functions/api/*', (_req, res) => {
    res.status(404).json({ error: 'API endpoint not found.' });
  });

  return app;
}
