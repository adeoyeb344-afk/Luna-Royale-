import nodemailer from 'nodemailer';

export interface NotificationItem {
  name: string;
  quantity: number;
  price: number;
  categoryLabel?: string;
}

export interface OrderNotificationPayload {
  orderId: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  items: NotificationItem[];
  subtotal: number;
  shippingFee: number;
  totalAmount: number;
  deliveryAddress: string;
  courier: string;
  paymentStatus: string;
  paymentReference?: string;
  deliveryPaymentMethod?: string;
  isTest?: boolean;
}

export interface NotificationLog {
  id: string;
  timestamp: string;
  channel: 'email' | 'whatsapp';
  orderId: string;
  recipient: string;
  status: 'delivered' | 'pending_credentials' | 'failed' | 'simulated';
  provider: string;
  messagePreview: string;
  errorDetails?: string;
  isTest?: boolean;
}

// In-memory log store (keeps last 200 logs)
const notificationLogs: NotificationLog[] = [];

// Deduplication key set: `${orderId}:${channel}` to prevent duplicate alerts
const processedNotificationKeys = new Set<string>();

export const DEFAULT_ADMIN_EMAIL = 'adeoyeb344@gmail.com';
export const DEFAULT_ADMIN_WHATSAPP = '+2349075130157';

export function getAdminEmail(): string {
  return (process.env.ADMIN_NOTIFICATION_EMAIL || DEFAULT_ADMIN_EMAIL).trim();
}

export function getAdminWhatsApp(): string {
  return (process.env.ADMIN_NOTIFICATION_WHATSAPP || DEFAULT_ADMIN_WHATSAPP).trim();
}

export function getNotificationLogs(): NotificationLog[] {
  return [...notificationLogs].reverse();
}

export function recordLog(log: Omit<NotificationLog, 'id' | 'timestamp'>): NotificationLog {
  const newLog: NotificationLog = {
    ...log,
    id: `notif_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
    timestamp: new Date().toISOString(),
  };

  notificationLogs.push(newLog);
  if (notificationLogs.length > 200) {
    notificationLogs.shift();
  }

  return newLog;
}

/**
 * Format currency in Nigerian Naira (₦)
 */
function formatNaira(amount: number): string {
  return `₦${Math.round(amount).toLocaleString('en-NG')}`;
}

/**
 * Clean phone number for WhatsApp API (e.g. +2349075130157 -> 2349075130157)
 */
function cleanWhatsAppNumber(phone: string): string {
  return phone.replace(/[^0-9]/g, '');
}

/**
 * Generate formatted WhatsApp message matching exact specification:
 *
 * LUNA ROYALE — NEW ORDER ALERT
 *
 * A new customer order has been received.
 *
 * Order Number: [Order Number]
 * Customer: [Customer Name]
 * Phone: [Customer Phone]
 * Products: [Products]
 * Delivery Address: [Delivery Address]
 * Delivery Fee: [Delivery Fee]
 * Total: [Total]
 * Payment Status: [Payment Status]
 *
 * Please check your LUNA ROYALE Admin Dashboard.
 */
export function formatWhatsAppOrderMessage(payload: OrderNotificationPayload): string {
  const productsSummary = payload.items
    .map((item) => `${item.name} (x${item.quantity}) - ${formatNaira(item.price * item.quantity)}`)
    .join(', ');

  const formattedFee =
    payload.shippingFee > 0
      ? formatNaira(payload.shippingFee)
      : '₦0 (Included / Free)';

  const formattedTotal = formatNaira(payload.totalAmount);

  return `LUNA ROYALE — NEW ORDER ALERT

A new customer order has been received.

Order Number: ${payload.orderId}
Customer: ${payload.customerName}
Phone: ${payload.customerPhone || 'N/A'}
Products: ${productsSummary}
Delivery Address: ${payload.deliveryAddress} (${payload.courier || 'Standard Courier'})
Delivery Fee: ${formattedFee}
Total: ${formattedTotal}
Payment Status: ${payload.paymentStatus}

Please check your LUNA ROYALE Admin Dashboard.`;
}

/**
 * Generate luxury HTML & plaintext email for store administrator.
 * Subject: NEW ORDER RECEIVED — LUNA ROYALE
 */
export function formatEmailOrderMessage(payload: OrderNotificationPayload): {
  subject: string;
  text: string;
  html: string;
} {
  const subject = `NEW ORDER RECEIVED — LUNA ROYALE (#${payload.orderId})`;

  const itemsRows = payload.items
    .map(
      (item) => `
      <tr>
        <td style="padding: 10px 0; border-bottom: 1px solid #e5e0d8; font-size: 13px; color: #0b0b0b;">
          <strong>${item.name}</strong>
          ${item.categoryLabel ? `<br><span style="font-size: 11px; color: #701F36; text-transform: uppercase;">${item.categoryLabel}</span>` : ''}
        </td>
        <td style="padding: 10px 0; border-bottom: 1px solid #e5e0d8; font-size: 13px; color: #0b0b0b; text-align: center;">
          ${item.quantity}
        </td>
        <td style="padding: 10px 0; border-bottom: 1px solid #e5e0d8; font-size: 13px; color: #0b0b0b; text-align: right; font-family: monospace;">
          ${formatNaira(item.price * item.quantity)}
        </td>
      </tr>
    `
    )
    .join('');

  const plainText = `NEW ORDER RECEIVED — LUNA ROYALE
========================================

A new order has been received at LUNA ROYALE.

Order Reference: #${payload.orderId}
Customer: ${payload.customerName} (${payload.customerEmail}, ${payload.customerPhone})
Payment Status: ${payload.paymentStatus} ${payload.paymentReference ? `(Ref: ${payload.paymentReference})` : ''}

DELIVERY DETAILS:
-----------------
Address: ${payload.deliveryAddress}
Courier Route: ${payload.courier || 'Standard Delivery'}
Delivery Payment: ${payload.deliveryPaymentMethod === 'courier_on_arrival' ? 'Pay to courier on arrival' : 'Paid online via Paystack'}

ORDER ITEMS:
------------
${payload.items.map((i) => `- ${i.name} x${i.quantity} = ${formatNaira(i.price * i.quantity)}`).join('\n')}

FINANCIAL BREAKDOWN:
--------------------
Products Subtotal: ${formatNaira(payload.subtotal)}
Delivery Fee: ${formatNaira(payload.shippingFee)}
Total Amount: ${formatNaira(payload.totalAmount)}

Access the Admin Dashboard to fulfill this order.
LUNA ROYALE · Elegance, Curated.`;

  const html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>New Order Received — LUNA ROYALE</title>
</head>
<body style="margin: 0; padding: 0; background-color: #F8F6EF; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; color: #0B0B0B;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #F8F6EF; padding: 30px 15px;">
    <tr>
      <td align="center">
        <table width="600" cellpadding="0" cellspacing="0" style="max-width: 600px; width: 100%; background-color: #FFFFFF; border: 1px solid #E5E0D8; padding: 32px 36px; box-shadow: 0 4px 12px rgba(0,0,0,0.03);">
          
          <!-- Header -->
          <tr>
            <td align="center" style="border-bottom: 2px solid #701F36; padding-bottom: 20px;">
              <span style="font-size: 10px; letter-spacing: 0.25em; text-transform: uppercase; color: #701F36; font-weight: 600;">LUNA ROYALE</span>
              <h1 style="margin: 8px 0 0 0; font-family: Georgia, serif; font-size: 22px; font-weight: normal; color: #0B0B0B; letter-spacing: 0.05em;">
                New Order Received
              </h1>
              <p style="margin: 4px 0 0 0; font-family: monospace; font-size: 12px; color: #666666;">
                Order Reference: #${payload.orderId}
              </p>
            </td>
          </tr>

          <!-- Customer & Status Summary -->
          <tr>
            <td style="padding: 24px 0 16px 0;">
              <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #F9F8F5; border: 1px solid #EBE7DF; padding: 16px;">
                <tr>
                  <td width="50%" valign="top" style="font-size: 12px; line-height: 1.6;">
                    <strong style="color: #701F36; text-transform: uppercase; font-size: 10px; letter-spacing: 0.1em; display: block; margin-bottom: 4px;">Customer Details</strong>
                    <strong>${payload.customerName}</strong><br>
                    <a href="mailto:${payload.customerEmail}" style="color: #0B0B0B; text-decoration: none;">${payload.customerEmail}</a><br>
                    Tel: ${payload.customerPhone || 'N/A'}
                  </td>
                  <td width="50%" valign="top" style="font-size: 12px; line-height: 1.6;">
                    <strong style="color: #701F36; text-transform: uppercase; font-size: 10px; letter-spacing: 0.1em; display: block; margin-bottom: 4px;">Order Status</strong>
                    Payment: <strong style="color: ${payload.paymentStatus.toLowerCase().includes('paid') || payload.paymentStatus.toLowerCase().includes('confirmed') ? '#15803d' : '#854d0e'};">${payload.paymentStatus}</strong><br>
                    ${payload.paymentReference ? `Paystack Ref: <span style="font-family: monospace; font-size: 11px;">${payload.paymentReference}</span><br>` : ''}
                    Date: ${new Date().toLocaleString('en-NG', { timeZone: 'Africa/Lagos' })} WAT
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- Delivery Information -->
          <tr>
            <td style="padding-bottom: 20px;">
              <table width="100%" cellpadding="0" cellspacing="0" style="border: 1px solid #EBE7DF; padding: 14px 16px; background-color: #FFFFFF;">
                <tr>
                  <td style="font-size: 12px; line-height: 1.6;">
                    <strong style="color: #701F36; text-transform: uppercase; font-size: 10px; letter-spacing: 0.1em; display: block; margin-bottom: 4px;">Delivery Destination & Route</strong>
                    ${payload.deliveryAddress}<br>
                    <strong>Courier:</strong> ${payload.courier || 'Standard Courier'} · 
                    <span style="color: #666666;">${payload.deliveryPaymentMethod === 'courier_on_arrival' ? 'Pay delivery on arrival' : 'Paid online via Paystack'}</span>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- Products Table -->
          <tr>
            <td>
              <strong style="color: #701F36; text-transform: uppercase; font-size: 11px; letter-spacing: 0.1em; display: block; margin-bottom: 8px;">Order Items</strong>
              <table width="100%" cellpadding="0" cellspacing="0" style="border-collapse: collapse;">
                <thead>
                  <tr style="border-bottom: 1px solid #0B0B0B; text-align: left; font-size: 10px; text-transform: uppercase; color: #666666; letter-spacing: 0.05em;">
                    <th style="padding-bottom: 6px;">Item</th>
                    <th style="padding-bottom: 6px; text-align: center;">Qty</th>
                    <th style="padding-bottom: 6px; text-align: right;">Amount</th>
                  </tr>
                </thead>
                <tbody>
                  ${itemsRows}
                </tbody>
              </table>
            </td>
          </tr>

          <!-- Totals Breakdown -->
          <tr>
            <td style="padding-top: 16px;">
              <table width="100%" cellpadding="0" cellspacing="0" style="border-top: 1px solid #E5E0D8; padding-top: 12px; font-size: 13px;">
                <tr>
                  <td style="padding: 4px 0; color: #666666;">Product Subtotal:</td>
                  <td style="padding: 4px 0; text-align: right; font-family: monospace;">${formatNaira(payload.subtotal)}</td>
                </tr>
                <tr>
                  <td style="padding: 4px 0; color: #666666;">Delivery Fee:</td>
                  <td style="padding: 4px 0; text-align: right; font-family: monospace; color: #701F36;">${formatNaira(payload.shippingFee)}</td>
                </tr>
                <tr style="font-size: 15px; font-weight: bold; border-top: 2px solid #0B0B0B;">
                  <td style="padding: 10px 0 0 0; color: #0B0B0B;">Total Payable:</td>
                  <td style="padding: 10px 0 0 0; text-align: right; color: #701F36; font-family: monospace;">${formatNaira(payload.totalAmount)}</td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- Footer -->
          <tr>
            <td align="center" style="border-top: 1px solid #E5E0D8; margin-top: 30px; padding-top: 24px; font-size: 11px; color: #888888; line-height: 1.5;">
              <p style="margin: 0;">This is an automated administrator alert sent from the LUNA ROYALE backend server.</p>
              <p style="margin: 4px 0 0 0;">LUNA ROYALE Atelier & E-Commerce Platform · Lagos, Nigeria</p>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>
</body>
</html>`;

  return { subject, text: plainText, html };
}

/**
 * Sends transactional email to the store administrator.
 * Independent execution: failures do not throw or cancel order.
 */
export async function sendAdminOrderEmail(
  payload: OrderNotificationPayload
): Promise<{ success: boolean; provider: string; message: string }> {
  const recipientEmail = getAdminEmail();
  const emailContent = formatEmailOrderMessage(payload);

  // 1. Check Resend API
  const resendApiKey = process.env.RESEND_API_KEY?.trim();
  if (resendApiKey && !resendApiKey.includes('MY_')) {
    try {
      const fromAddress = process.env.EMAIL_FROM?.trim() || 'LUNA ROYALE <onboarding@resend.dev>';
      const res = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${resendApiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          from: fromAddress,
          to: [recipientEmail],
          subject: emailContent.subject,
          text: emailContent.text,
          html: emailContent.html,
        }),
      });

      const data = await res.json().catch(() => ({}));
      if (res.ok) {
        recordLog({
          channel: 'email',
          orderId: payload.orderId,
          recipient: recipientEmail,
          status: 'delivered',
          provider: 'Resend API',
          messagePreview: `Subject: ${emailContent.subject}`,
          isTest: payload.isTest,
        });
        return { success: true, provider: 'Resend', message: 'Email sent successfully via Resend.' };
      } else {
        const errorMsg = data?.message || `Resend returned status ${res.status}`;
        recordLog({
          channel: 'email',
          orderId: payload.orderId,
          recipient: recipientEmail,
          status: 'failed',
          provider: 'Resend API',
          messagePreview: `Subject: ${emailContent.subject}`,
          errorDetails: errorMsg,
          isTest: payload.isTest,
        });
        // Continue to fallback
      }
    } catch (err: any) {
      recordLog({
        channel: 'email',
        orderId: payload.orderId,
        recipient: recipientEmail,
        status: 'failed',
        provider: 'Resend API',
        messagePreview: `Subject: ${emailContent.subject}`,
        errorDetails: err?.message || 'Network error',
        isTest: payload.isTest,
      });
    }
  }

  // 2. Check SendGrid API
  const sendgridApiKey = process.env.SENDGRID_API_KEY?.trim();
  if (sendgridApiKey && !sendgridApiKey.includes('MY_')) {
    try {
      const fromAddress = process.env.EMAIL_FROM?.trim() || 'orders@lunaroyale.com';
      const res = await fetch('https://api.sendgrid.com/v3/mail/send', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${sendgridApiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          personalizations: [{ to: [{ email: recipientEmail }] }],
          from: { email: fromAddress, name: 'LUNA ROYALE' },
          subject: emailContent.subject,
          content: [
            { type: 'text/plain', value: emailContent.text },
            { type: 'text/html', value: emailContent.html },
          ],
        }),
      });

      if (res.ok || res.status === 202) {
        recordLog({
          channel: 'email',
          orderId: payload.orderId,
          recipient: recipientEmail,
          status: 'delivered',
          provider: 'SendGrid API',
          messagePreview: `Subject: ${emailContent.subject}`,
          isTest: payload.isTest,
        });
        return { success: true, provider: 'SendGrid', message: 'Email sent successfully via SendGrid.' };
      }
    } catch (err: any) {
      // Continue to SMTP
    }
  }

  // 3. Check SMTP Configuration
  const smtpHost = process.env.SMTP_HOST?.trim();
  const smtpUser = process.env.SMTP_USER?.trim();
  const smtpPass = process.env.SMTP_PASS?.trim();
  if (smtpHost && smtpUser && smtpPass) {
    try {
      const port = Number(process.env.SMTP_PORT) || 587;
      const secure = process.env.SMTP_SECURE === 'true' || port === 465;
      const transporter = nodemailer.createTransport({
        host: smtpHost,
        port,
        secure,
        auth: { user: smtpUser, pass: smtpPass },
      });

      await transporter.sendMail({
        from: process.env.EMAIL_FROM?.trim() || `LUNA ROYALE <${smtpUser}>`,
        to: recipientEmail,
        subject: emailContent.subject,
        text: emailContent.text,
        html: emailContent.html,
      });

      recordLog({
        channel: 'email',
        orderId: payload.orderId,
        recipient: recipientEmail,
        status: 'delivered',
        provider: `SMTP (${smtpHost})`,
        messagePreview: `Subject: ${emailContent.subject}`,
        isTest: payload.isTest,
      });

      return { success: true, provider: 'SMTP', message: `Email sent successfully via SMTP (${smtpHost}).` };
    } catch (err: any) {
      recordLog({
        channel: 'email',
        orderId: payload.orderId,
        recipient: recipientEmail,
        status: 'failed',
        provider: `SMTP (${smtpHost})`,
        messagePreview: `Subject: ${emailContent.subject}`,
        errorDetails: err?.message || 'SMTP delivery failure',
        isTest: payload.isTest,
      });
    }
  }

  // 4. No credentials configured yet -> Log gracefully without throwing
  recordLog({
    channel: 'email',
    orderId: payload.orderId,
    recipient: recipientEmail,
    status: 'pending_credentials',
    provider: 'Transactional Email Engine',
    messagePreview: `Subject: ${emailContent.subject} (Subtotal: ${formatNaira(payload.subtotal)}, Total: ${formatNaira(payload.totalAmount)})`,
    errorDetails: 'Email API key not yet configured on server (RESEND_API_KEY, SENDGRID_API_KEY, or SMTP_HOST/USER/PASS). Notification logged for administrator review.',
    isTest: payload.isTest,
  });

  return {
    success: false,
    provider: 'None',
    message: 'Email credentials not configured yet. Notification logged.',
  };
}

/**
 * Sends WhatsApp notification to the store administrator (+2349075130157).
 * Supports official Meta WhatsApp Business Cloud API or Twilio WhatsApp.
 * Independent execution: failures do not throw or cancel order.
 */
export async function sendAdminOrderWhatsApp(
  payload: OrderNotificationPayload
): Promise<{ success: boolean; provider: string; message: string }> {
  const recipientNumber = getAdminWhatsApp();
  const cleanPhone = cleanWhatsAppNumber(recipientNumber);
  const messageText = formatWhatsAppOrderMessage(payload);

  // 1. Meta WhatsApp Business Cloud API (Official Graph API)
  const metaToken = process.env.WHATSAPP_API_TOKEN?.trim();
  const metaPhoneId = process.env.WHATSAPP_PHONE_NUMBER_ID?.trim();

  if (metaToken && metaPhoneId && !metaToken.includes('MY_')) {
    try {
      // First try sending template message if template is configured
      const templateName = process.env.WHATSAPP_TEMPLATE_NAME?.trim();
      const templateLang = process.env.WHATSAPP_TEMPLATE_LANGUAGE?.trim() || 'en';

      let requestBody: Record<string, unknown>;

      if (templateName) {
        requestBody = {
          messaging_product: 'whatsapp',
          recipient_type: 'individual',
          to: cleanPhone,
          type: 'template',
          template: {
            name: templateName,
            language: { code: templateLang },
            components: [
              {
                type: 'body',
                parameters: [
                  { type: 'text', text: payload.orderId },
                  { type: 'text', text: payload.customerName },
                  { type: 'text', text: payload.customerPhone || 'N/A' },
                  { type: 'text', text: payload.items.map((i) => `${i.name} (x${i.quantity})`).join(', ') },
                  { type: 'text', text: payload.deliveryAddress },
                  { type: 'text', text: formatNaira(payload.shippingFee) },
                  { type: 'text', text: formatNaira(payload.totalAmount) },
                  { type: 'text', text: payload.paymentStatus },
                ],
              },
            ],
          },
        };
      } else {
        // Standard text message (works within 24h customer window or testing numbers)
        requestBody = {
          messaging_product: 'whatsapp',
          recipient_type: 'individual',
          to: cleanPhone,
          type: 'text',
          text: { preview_url: false, body: messageText },
        };
      }

      const res = await fetch(
        `https://graph.facebook.com/v20.0/${encodeURIComponent(metaPhoneId)}/messages`,
        {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${metaToken}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(requestBody),
        }
      );

      const data = await res.json().catch(() => ({}));

      if (res.ok && data?.messages?.[0]?.id) {
        recordLog({
          channel: 'whatsapp',
          orderId: payload.orderId,
          recipient: recipientNumber,
          status: 'delivered',
          provider: 'Meta WhatsApp Cloud API',
          messagePreview: messageText.substring(0, 150) + '...',
          isTest: payload.isTest,
        });

        return {
          success: true,
          provider: 'Meta Cloud API',
          message: 'WhatsApp notification sent via official Meta Cloud API.',
        };
      } else {
        const errorMsg =
          data?.error?.message ||
          data?.error?.error_user_msg ||
          `Meta Graph API returned status ${res.status}`;

        recordLog({
          channel: 'whatsapp',
          orderId: payload.orderId,
          recipient: recipientNumber,
          status: 'failed',
          provider: 'Meta WhatsApp Cloud API',
          messagePreview: messageText.substring(0, 150) + '...',
          errorDetails: errorMsg,
          isTest: payload.isTest,
        });
      }
    } catch (err: any) {
      recordLog({
        channel: 'whatsapp',
        orderId: payload.orderId,
        recipient: recipientNumber,
        status: 'failed',
        provider: 'Meta WhatsApp Cloud API',
        messagePreview: messageText.substring(0, 150) + '...',
        errorDetails: err?.message || 'Network communication error',
        isTest: payload.isTest,
      });
    }
  }

  // 2. Twilio WhatsApp Provider (Alternative)
  const twilioSid = process.env.TWILIO_ACCOUNT_SID?.trim();
  const twilioToken = process.env.TWILIO_AUTH_TOKEN?.trim();
  const twilioFrom = process.env.TWILIO_WHATSAPP_NUMBER?.trim();

  if (twilioSid && twilioToken && twilioFrom) {
    try {
      const fromParam = twilioFrom.startsWith('whatsapp:') ? twilioFrom : `whatsapp:${twilioFrom}`;
      const toParam = `whatsapp:${recipientNumber.startsWith('+') ? recipientNumber : `+${recipientNumber}`}`;

      const params = new URLSearchParams();
      params.append('From', fromParam);
      params.append('To', toParam);
      params.append('Body', messageText);

      const authHeader = Buffer.from(`${twilioSid}:${twilioToken}`).toString('base64');
      const res = await fetch(
        `https://api.twilio.com/2010-04-01/Accounts/${encodeURIComponent(twilioSid)}/Messages.json`,
        {
          method: 'POST',
          headers: {
            Authorization: `Basic ${authHeader}`,
            'Content-Type': 'application/x-www-form-urlencoded',
          },
          body: params.toString(),
        }
      );

      const data = await res.json().catch(() => ({}));
      if (res.ok && data?.sid) {
        recordLog({
          channel: 'whatsapp',
          orderId: payload.orderId,
          recipient: recipientNumber,
          status: 'delivered',
          provider: 'Twilio WhatsApp',
          messagePreview: messageText.substring(0, 150) + '...',
          isTest: payload.isTest,
        });

        return {
          success: true,
          provider: 'Twilio WhatsApp',
          message: 'WhatsApp notification sent via Twilio.',
        };
      }
    } catch (err: any) {
      // Continue to unconfigured fallback
    }
  }

  // 3. WhatsApp Credentials Not Configured -> Log gracefully
  recordLog({
    channel: 'whatsapp',
    orderId: payload.orderId,
    recipient: recipientNumber,
    status: 'pending_credentials',
    provider: 'WhatsApp Business Engine',
    messagePreview: messageText.substring(0, 150) + '...',
    errorDetails:
      'WhatsApp Business Cloud API credentials not yet set on server (WHATSAPP_API_TOKEN or WHATSAPP_PHONE_NUMBER_ID). Notification logged for administrator review.',
    isTest: payload.isTest,
  });

  return {
    success: false,
    provider: 'None',
    message: 'WhatsApp Business credentials not configured yet. Notification logged.',
  };
}

/**
 * Dispatches both Email and WhatsApp notifications independently.
 * Deduplicates notifications per order to avoid spamming the administrator.
 */
export async function dispatchNewOrderNotifications(
  payload: OrderNotificationPayload
): Promise<{
  emailResult: { success: boolean; provider: string; message: string };
  whatsAppResult: { success: boolean; provider: string; message: string };
  deduplicated?: boolean;
}> {
  // Prevent duplicate notifications for identical order ID
  const emailKey = `${payload.orderId}:email`;
  const whatsappKey = `${payload.orderId}:whatsapp`;

  const isEmailAlreadySent = !payload.isTest && processedNotificationKeys.has(emailKey);
  const isWhatsAppAlreadySent = !payload.isTest && processedNotificationKeys.has(whatsappKey);

  if (isEmailAlreadySent && isWhatsAppAlreadySent) {
    return {
      emailResult: { success: true, provider: 'Cache', message: 'Notification already sent previously.' },
      whatsAppResult: { success: true, provider: 'Cache', message: 'Notification already sent previously.' },
      deduplicated: true,
    };
  }

  // Run both notification channels independently with Promise.allSettled
  const [emailSettled, whatsAppSettled] = await Promise.allSettled([
    !isEmailAlreadySent
      ? sendAdminOrderEmail(payload).then((res) => {
          if (!payload.isTest && res.success) processedNotificationKeys.add(emailKey);
          return res;
        })
      : Promise.resolve({ success: true, provider: 'Cache', message: 'Already sent' }),
    !isWhatsAppAlreadySent
      ? sendAdminOrderWhatsApp(payload).then((res) => {
          if (!payload.isTest && res.success) processedNotificationKeys.add(whatsappKey);
          return res;
        })
      : Promise.resolve({ success: true, provider: 'Cache', message: 'Already sent' }),
  ]);

  const emailResult =
    emailSettled.status === 'fulfilled'
      ? emailSettled.value
      : { success: false, provider: 'Error', message: 'Email dispatch encountered an unhandled exception.' };

  const whatsAppResult =
    whatsAppSettled.status === 'fulfilled'
      ? whatsAppSettled.value
      : { success: false, provider: 'Error', message: 'WhatsApp dispatch encountered an unhandled exception.' };

  return { emailResult, whatsAppResult };
}
