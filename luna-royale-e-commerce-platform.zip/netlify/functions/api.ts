import type express from 'express';
import serverless from 'serverless-http';
import { createApiApp } from '../../serverApi';

const app = createApiApp();

// Catch-all for any path reaching the Netlify Function that did not match an API route
app.use((_req: express.Request, res: express.Response) => {
  res.status(404).json({ error: 'API endpoint not found.' });
});

// Express error middleware: never emit Express default HTML error pages
app.use(
  (
    err: any,
    _req: express.Request,
    res: express.Response,
    _next: express.NextFunction
  ) => {
    const status = typeof err?.status === 'number' ? err.status : 500;
    res.status(status).json({
      error: err?.message || 'Unexpected server error processing API request.',
    });
  }
);

const serverlessHandler = serverless(app);

export const handler = async (event: any, context: any) => {
  try {
    return await serverlessHandler(event, context);
  } catch (err: any) {
    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        error: err?.message || 'Serverless function execution failed.',
      }),
    };
  }
};
